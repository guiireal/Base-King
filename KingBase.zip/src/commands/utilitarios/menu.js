module.exports = {
    name: "menu",
    async execute(client, msg, args, king, config) {
        await king.kingmsg(`Menu do ${config.nome_bot}`);
    }
};

